
import pygame
import sys

WIDTH, HEIGHT = 800, 480
GREEN = (0, 255, 70)
BLACK = (0, 0, 0)
FPS = 60

TABS = ["STAT", "INV", "DATA", "MAP", "RADIO"]

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
clock = pygame.time.Clock()
font_big = pygame.font.SysFont("monospace", 48, bold=True)
font_med = pygame.font.SysFont("monospace", 26)
font_small = pygame.font.SysFont("monospace", 18)

current_tab = 0

def draw_tabs():
    tab_width = WIDTH // len(TABS)
    for i, tab in enumerate(TABS):
        x = i * tab_width
        color = GREEN if i == current_tab else (0, 120, 40)
        pygame.draw.rect(screen, color, (x, 0, tab_width, 40), 2)
        label = font_small.render(tab, True, color)
        screen.blit(label, (x + tab_width//2 - label.get_width()//2, 10))

def draw_content():
    label = font_big.render(TABS[current_tab], True, GREEN)
    screen.blit(label, (40, 100))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if y < 40:
                current_tab = x // (WIDTH // len(TABS))

    screen.fill(BLACK)
    draw_tabs()
    draw_content()
    pygame.display.flip()
    clock.tick(FPS)
