import pypboy


class Module(pypboy.SubModule):

	label = "Quests"
